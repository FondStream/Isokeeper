# IsoKeeper

Android quick-reference guide and tracker for an isopod breeding project.

- **Chores** – auto-scheduled per colony from species needs (misting, feeding, protein, mould checks, leaf litter, calcium, headcount, substrate refresh). Tick off or push back a day.
- **Colonies** – species/morph, tub, counts, temp/humidity, ventilation, substrate, tub contents, quick log (mancae, counts, readings, notes) and history.
- **Setup vs ideal** – compares each tub with the species' ideal ranges and must-haves.
- **Guide** – care sheets for Armadillidium, Cubaris, Porcellio and Porcellionides, plus basics.
- **Backup** – share/restore all data as text.

## Building
Every push to GitHub builds the APK automatically (`.github/workflows/build.yml`).
Open the repo's **Releases** page on your phone and download `IsoKeeper.apk`.

The app is in `app/src/main/assets/index.html`; the Android shell is `MainActivity.java`.
